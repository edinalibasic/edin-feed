package com.edin.feed;
import android.content.*;import java.util.*;
public class SourceStore{
 static final String P="sources8",K="items";
 static final String[] D={"klix.ba","nezavisne.com","avaz.ba","vijesti.ba","Živinice","Tuzla OR \"Tuzlanski kanton\"","Augsburg Germany","AI technology","stock market"};
 static LinkedHashSet<String> get(Context c){Set<String>s=c.getSharedPreferences(P,0).getStringSet(K,null);return s==null?new LinkedHashSet<>(Arrays.asList(D)):new LinkedHashSet<>(s);}
 static void save(Context c,Set<String>s){c.getSharedPreferences(P,0).edit().putStringSet(K,new HashSet<>(s)).apply();}
}
