package com.edin.feed;
import android.content.*;import android.graphics.drawable.ColorDrawable;import android.view.*;import android.widget.*;import androidx.recyclerview.widget.RecyclerView;import com.squareup.picasso.*;import java.util.*;
public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.H>{
 Context c;List<MainActivity.Item>d;
 NewsAdapter(Context c,List<MainActivity.Item>d){this.c=c;this.d=d;}
 public H onCreateViewHolder(ViewGroup p,int t){return new H(LayoutInflater.from(c).inflate(R.layout.item_news,p,false));}
 public void onBindViewHolder(H h,int pos){ItemBinder.bind(c,h,d.get(pos));}
 public int getItemCount(){return d.size();}
 static class ItemBinder{
  static void bind(Context c,H h,MainActivity.Item i){
   h.title.setText(i.cleanTitle);h.source.setText(i.source+" · "+MainActivity.rel(i.when));h.image.setVisibility(View.GONE);h.image.setImageDrawable(null);
   Picasso.get().cancelRequest(h.image);
   if(MainActivity.goodImage(i.image)){
    Picasso.get().load(i.image).fit().centerCrop().into(h.image,new Callback(){
     public void onSuccess(){h.image.setVisibility(View.VISIBLE);}
     public void onError(Exception e){h.image.setVisibility(View.GONE);h.image.setImageDrawable(null);i.image=null;}
    });
   }
   View.OnClickListener open=v->{try{Intent x=new Intent(c,BrowserActivity.class);x.putExtra("url",i.url);x.putExtra("title",i.source);c.startActivity(x);}catch(Throwable e){}};
   h.card.setOnClickListener(open);h.title.setOnClickListener(open);h.image.setOnClickListener(open);
   h.heart.setOnClickListener(v->h.heart.setText(h.heart.getText().toString().equals("♡")?"♥":"♡"));
   h.share.setOnClickListener(v->{try{Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,i.cleanTitle+"\n"+i.url);c.startActivity(Intent.createChooser(s,"Podijeli"));}catch(Throwable e){}});
   h.more.setOnClickListener(v->{PopupMenu p=new PopupMenu(c,h.more);p.getMenu().add("Ne zanima me");p.getMenu().add("Manje ovakvih");p.getMenu().add("Sakrij izvor");p.show();});
  }}
 static class H extends RecyclerView.ViewHolder{View card;ImageView image;TextView title,source,heart,share,more;H(View v){super(v);card=v.findViewById(R.id.card);image=v.findViewById(R.id.image);title=v.findViewById(R.id.title);source=v.findViewById(R.id.source);heart=v.findViewById(R.id.heart);share=v.findViewById(R.id.share);more=v.findViewById(R.id.more);}}
}
