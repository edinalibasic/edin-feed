package com.edin.feed;
import android.content.*;import android.graphics.Color;import android.os.*;import android.text.Html;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import androidx.recyclerview.widget.*;import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import org.w3c.dom.*;import javax.xml.parsers.*;import java.net.*;import java.text.*;import java.util.*;import java.util.concurrent.*;import java.util.regex.*;
public class MainActivity extends AppCompatActivity{
 RecyclerView rv;SwipeRefreshLayout swipe;LinearLayout cats;NewsAdapter adapter;final ArrayList<Item> master=new ArrayList<>(),shown=new ArrayList<>();ExecutorService io=Executors.newFixedThreadPool(3);ExecutorService images=Executors.newFixedThreadPool(2);Set<String> imageJobs=Collections.synchronizedSet(new HashSet<>());volatile boolean loading=false;String category="Sve";final int PAGE=12;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);rv=findViewById(R.id.list);swipe=findViewById(R.id.swipe);cats=findViewById(R.id.categories);rv.setLayoutManager(new LinearLayoutManager(this));adapter=new NewsAdapter(this,shown);rv.setAdapter(adapter);makeCats();
  findViewById(R.id.sources).setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));swipe.setOnRefreshListener(this::reload);
  rv.addOnScrollListener(new RecyclerView.OnScrollListener(){public void onScrolled(RecyclerView r,int dx,int dy){if(dy<=0)return;LinearLayoutManager lm=(LinearLayoutManager)r.getLayoutManager();if(lm!=null&&lm.findLastVisibleItemPosition()>=shown.size()-3)append();}});
  reload();}
 void makeCats(){for(String x:new String[]{"Sve","BiH","Njemačka","Tehnologija","Berza"}){TextView v=new TextView(this);v.setText(x);v.setTag(x);v.setTextSize(16);v.setPadding(dp(17),dp(9),dp(17),dp(9));v.setOnClickListener(z->{category=(String)z.getTag();style();resetPage();});cats.addView(v);}style();}
 void style(){for(int i=0;i<cats.getChildCount();i++){TextView v=(TextView)cats.getChildAt(i);boolean on=category.equals(v.getTag());v.setTextColor(on?Color.WHITE:Color.DKGRAY);v.setBackgroundResource(on?R.drawable.chip:0);}}
 void reload(){if(loading)return;loading=true;swipe.setRefreshing(true);io.execute(()->{ArrayList<Item> tmp=new ArrayList<>();for(String q:SourceStore.get(this)){try{tmp.addAll(fetch(q));}catch(Throwable ignored){}}
  LinkedHashMap<String,Item> uniq=new LinkedHashMap<>();for(Item i:tmp){if(i.title==null||i.title.trim().isEmpty())continue;String k=i.title.toLowerCase().replaceAll("[^\\p{L}\\p{N}]","");if(!uniq.containsKey(k))uniq.put(k,i);}
  tmp=new ArrayList<>(uniq.values());Collections.sort(tmp,(a,b)->Long.compare(b.when,a.when));for(Item i:tmp){i.cleanTitle=clean(i.title,i.source);i.url=i.link;if(!goodImage(i.image))i.image=null;}
  ArrayList<Item> done=tmp;runOnUiThread(()->{master.clear();master.addAll(done);loading=false;swipe.setRefreshing(false);resetPage();});
 });}
 void resetPage(){shown.clear();adapter.notifyDataSetChanged();append();rv.scrollToPosition(0);}
 void append(){ArrayList<Item> f=filtered();int s=shown.size();if(s>=f.size())return;int e=Math.min(s+PAGE,f.size());shown.addAll(f.subList(s,e));adapter.notifyItemRangeInserted(s,e-s);loadImagesForRange(s,e);}
 ArrayList<Item> filtered(){if(category.equals("Sve"))return new ArrayList<>(master);ArrayList<Item> r=new ArrayList<>();for(Item i:master){String s=(" "+i.title+" "+i.source+" ").toLowerCase();boolean ok=false;
  if(category.equals("BiH"))ok=s.matches(".*(bosn|bih|tuzl|živinic|klix|avaz|vijesti|nezavisne).*");
  if(category.equals("Njemačka"))ok=s.matches(".*(german|njema|augsburg|berlin|münchen|bayern).*");
  if(category.equals("Tehnologija"))ok=s.matches(".*(technology|tech|\\bai\\b|software|android|google|apple|microsoft).*");
  if(category.equals("Berza"))ok=s.matches(".*(stock|market|berza|nasdaq|dow|invest|shares).*");if(ok)r.add(i);}return r;}

 void loadImagesForRange(int start,int end){
  for(int n=start;n<end&&n<shown.size();n++){
   Item item=shown.get(n);
   if(goodImage(item.image)||item.link==null||item.link.isEmpty()||!imageJobs.add(item.link))continue;
   images.execute(()->{
    String[] found=resolveArticleAndImage(item.link);
    if(found[0]!=null)item.url=found[0];
    if(goodImage(found[1]))item.image=found[1];
    runOnUiThread(()->{int p=shown.indexOf(item);if(p>=0)adapter.notifyItemChanged(p);});
   });
  }
 }
 String[] resolveArticleAndImage(String start){
  String current=start;String img=null;
  try{
   for(int hop=0;hop<4;hop++){
    HttpURLConnection c=(HttpURLConnection)new URL(current).openConnection();
    c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");
    c.setConnectTimeout(6000);c.setReadTimeout(6000);int code=c.getResponseCode();
    if(code>=300&&code<400){String loc=c.getHeaderField("Location");if(loc==null)break;current=new URL(new URL(current),loc).toString();continue;}
    String ct=c.getContentType();URL finalUrl=c.getURL();if(finalUrl!=null)current=finalUrl.toString();
    if(ct!=null&&ct.toLowerCase().contains("text")){
     java.io.BufferedReader br=new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream()));
     StringBuilder b=new StringBuilder();String line;int size=0;
     while((line=br.readLine())!=null&&size<450000){b.append(line);size+=line.length();}
     String h=b.toString();
     // Google News wrapper: first try to discover an original publisher URL embedded in the page.
     if(current.contains("news.google.com")){
      Matcher om=Pattern.compile("https?://(?!news\\.google\\.com|www\\.google\\.com|accounts\\.google\\.com)[^\\\"'<> ]+",Pattern.CASE_INSENSITIVE).matcher(h);
      while(om.find()){String cand=Html.fromHtml(om.group(),0).toString().replace("\\u003d","=").replace("\\u0026","&");if(cand.length()<1200){current=cand;break;}}
      if(!current.contains("news.google.com"))return resolveArticleAndImage(current);
     }
     Matcher m=Pattern.compile("<meta[^>]+(?:property|name)=[\"'](?:og:image|twitter:image(?::src)?)[\"'][^>]+content=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h);
     if(!m.find())m=Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"'](?:og:image|twitter:image(?::src)?)[\"']",Pattern.CASE_INSENSITIVE).matcher(h);
     if(m.find())img=Html.fromHtml(m.group(1),0).toString();
    }break;
   }
  }catch(Throwable ignored){}
  return new String[]{current,img};
 }
 ArrayList<Item> fetch(String q)throws Exception{if(q.startsWith("http"))return parse(q);String query=q.contains(".")&&!q.contains(" ")&&!q.startsWith("site:")?"site:"+q:q;String u="https://news.google.com/rss/search?q="+URLEncoder.encode(query,"UTF-8")+"&hl=bs&gl=BA&ceid=BA:bs";return parse(u);}
 ArrayList<Item> parse(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestProperty("User-Agent","Mozilla/5.0");c.setConnectTimeout(7000);c.setReadTimeout(7000);DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();Document d=f.newDocumentBuilder().parse(c.getInputStream());NodeList ns=d.getElementsByTagName("item");ArrayList<Item> out=new ArrayList<>();
  for(int n=0;n<ns.getLength()&&n<30;n++){Element e=(Element)ns.item(n);String title=t(e,"title"),link=t(e,"link"),date=t(e,"pubDate"),src="";NodeList sn=e.getElementsByTagName("source");if(sn.getLength()>0)src=sn.item(0).getTextContent();if(src.isEmpty())src="Vijesti";Item i=new Item(title,link,src,date(date));i.image=feedImage(e);out.add(i);}return out;}
 String feedImage(Element e){for(String tag:new String[]{"media:content","media:thumbnail","enclosure"}){NodeList n=e.getElementsByTagName(tag);for(int j=0;j<n.getLength();j++){Element x=(Element)n.item(j);String u=x.getAttribute("url");if(goodImage(u))return u;}}
  String h=t(e,"description")+" "+t(e,"content:encoded");Matcher m=Pattern.compile("<img[^>]+(?:src|data-src)=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h);if(m.find()&&goodImage(m.group(1)))return m.group(1);return null;}
 static boolean goodImage(String u){if(u==null||!u.startsWith("http"))return false;String x=u.toLowerCase();return !(x.contains("gstatic.com")||x.contains("google.com/images")||x.contains("google_news")||x.contains("googlenews")||x.contains("news.google.com"));}
 String t(Element e,String n){NodeList x=e.getElementsByTagName(n);return x.getLength()>0?x.item(0).getTextContent():"";}
 long date(String d){for(String p:new String[]{"EEE, dd MMM yyyy HH:mm:ss z","EEE, dd MMM yyyy HH:mm:ss Z"})try{return new SimpleDateFormat(p,Locale.US).parse(d).getTime();}catch(Exception e){}return 0;}
 String clean(String a,String s){String x=Html.fromHtml(a,0).toString().trim();if(s!=null&&!s.isEmpty())x=x.replaceAll("\\s+-\\s+"+Pattern.quote(s)+"\\s*$","").trim();return x;}
 static String rel(long t){if(t<=0)return"novo";long m=Math.max(1,(System.currentTimeMillis()-t)/60000);if(m<60)return m+"m";if(m<1440)return(m/60)+"h";return(m/1440)+"d";}
 int dp(int x){return(int)(x*getResources().getDisplayMetrics().density);}
 static class Item{String title,cleanTitle,link,source,url,image;long when;Item(String a,String b,String c,long d){title=a;cleanTitle=a;link=b;source=c;url=b;when=d;}}
}
