package com.edin.feed;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import android.content.*;import android.graphics.Color;import android.os.*;import android.text.Html;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import androidx.recyclerview.widget.*;import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import org.w3c.dom.*;import javax.xml.parsers.*;import java.net.*;import java.text.*;import java.util.*;import java.util.concurrent.*;import java.util.regex.*;
public class MainActivity extends AppCompatActivity{
 RecyclerView rv;SwipeRefreshLayout swipe;LinearLayout cats;NewsAdapter adapter;final ArrayList<Item> master=new ArrayList<>(),shown=new ArrayList<>();ExecutorService io=Executors.newFixedThreadPool(3);ExecutorService images=Executors.newFixedThreadPool(2);Set<String> imageJobs=Collections.synchronizedSet(new HashSet<>());volatile boolean loading=false;String category="Sve";final int PAGE=12;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);rv=findViewById(R.id.list);swipe=findViewById(R.id.swipe);cats=findViewById(R.id.categories);rv.setLayoutManager(new LinearLayoutManager(this));adapter=new NewsAdapter(this,shown);rv.setAdapter(adapter);makeCats();
  findViewById(R.id.sources).setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));swipe.setOnRefreshListener(this::reload);
  rv.addOnScrollListener(new RecyclerView.OnScrollListener(){public void onScrolled(RecyclerView r,int dx,int dy){if(dy<=0)return;LinearLayoutManager lm=(LinearLayoutManager)r.getLayoutManager();if(lm!=null&&lm.findLastVisibleItemPosition()>=shown.size()-3)append();}});
  reload();}
 void makeCats(){for(String x:new String[]{"Sve","BiH","Njemačka","Tehnologija","Berza"}){TextView v=new TextView(this);v.setText(x);v.setTag(x);v.setTextSize(16);v.setPadding(dp(17),dp(9),dp(17),dp(9));v.setOnClickListener(z->{category=(String)z.getTag();style();resetPage();});cats.addView(v);}style();}
 void style(){for(int i=0;i<cats.getChildCount();i++){TextView v=(TextView)cats.getChildAt(i);boolean on=category.equals(v.getTag());v.setTextColor(on?Color.WHITE:Color.DKGRAY);v.setBackgroundResource(on?R.drawable.chip:0);}}
 void reload(){if(loading)return;loading=true;swipe.setRefreshing(true);io.execute(()->{ArrayList<Item> tmp=new ArrayList<>();for(String q:SourceStore.get(this)){try{tmp.addAll(fetch(q));}catch(Throwable ignored){}}
  LinkedHashMap<String,Item> uniq=new LinkedHashMap<>();for(Item i:tmp){if(i.title==null||i.title.trim().isEmpty())continue;String k=i.title.toLowerCase().replaceAll("[^\\p{L}\\p{N}]","");if(!uniq.containsKey(k))uniq.put(k,i);}
  tmp=new ArrayList<>(uniq.values());Collections.sort(tmp,(a,b)->Long.compare(b.when,a.when));for(Item i:tmp){i.cleanTitle=clean(i.title,i.source);i.url=i.link;if(!goodImage(i.image))i.image=null;}
  ArrayList<Item> done=tmp;runOnUiThread(()->{master.clear();master.addAll(done);loading=false;swipe.setRefreshing(false);resetPage();});
 });}
 void resetPage(){shown.clear();adapter.notifyDataSetChanged();append();rv.scrollToPosition(0);}
 void append(){ArrayList<Item> f=filtered();int s=shown.size();if(s>=f.size())return;int e=Math.min(s+PAGE,f.size());shown.addAll(f.subList(s,e));adapter.notifyItemRangeInserted(s,e-s);loadImagesForRange(s,e);}
 ArrayList<Item> filtered(){if(category.equals("Sve"))return new ArrayList<>(master);ArrayList<Item> r=new ArrayList<>();for(Item i:master){String s=(" "+i.title+" "+i.source+" ").toLowerCase();boolean ok=false;
  if(category.equals("BiH"))ok=s.matches(".*(bosn|bih|tuzl|živinic|klix|avaz|vijesti|nezavisne).*");
  if(category.equals("Njemačka"))ok=s.matches(".*(german|njema|augsburg|berlin|münchen|bayern).*");
  if(category.equals("Tehnologija"))ok=s.matches(".*(technology|tech|\\bai\\b|software|android|google|apple|microsoft).*");
  if(category.equals("Berza"))ok=s.matches(".*(stock|market|berza|nasdaq|dow|invest|shares).*");if(ok)r.add(i);}return r;}

 void loadImagesForRange(int start,int end){
  for(int n=start;n<end&&n<shown.size();n++){
   Item item=shown.get(n);
   if(goodImage(item.image)||item.link==null||item.link.isEmpty()||!imageJobs.add(item.link))continue;
   images.execute(()->{
    String[] found=resolveArticleAndImage(item.link);
    if(found[0]!=null){item.url=found[0];String host=publisherName(found[0]);if(host!=null)item.source=host;}
    if(goodImage(found[1]))item.image=found[1];
    runOnUiThread(()->{int p=shown.indexOf(item);if(p>=0)adapter.notifyItemChanged(p);});
   });
  }
 }
 String[] resolveArticleAndImage(String start){
  String current=start,img=null;
  try{
   for(int hop=0;hop<5;hop++){
    HttpURLConnection c=(HttpURLConnection)new URL(current).openConnection();
    c.setInstanceFollowRedirects(false);
    c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Mobile Safari/537.36");
    c.setRequestProperty("Accept","text/html,application/xhtml+xml");
    c.setConnectTimeout(7000);c.setReadTimeout(7000);
    int code=c.getResponseCode();
    if(code>=300&&code<400){String loc=c.getHeaderField("Location");if(loc==null)break;current=new URL(new URL(current),loc).toString();continue;}
    String ct=c.getContentType();
    if(ct==null||!ct.toLowerCase().contains("text"))break;
    java.io.BufferedReader br=new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream()));
    StringBuilder b=new StringBuilder();String line;int size=0;
    while((line=br.readLine())!=null&&size<1000000){b.append(line).append('\n');size+=line.length();}
    String h=b.toString();

    if(current.contains("news.google.com")){
     String publisher=publisherUrlFromGoogle(h);
     if(publisher!=null&&!publisher.equals(current)){current=publisher;continue;}
    }
    img=imageFromHtml(h,current);
    break;
   }
  }catch(Throwable ignored){}
  return new String[]{current,img};
 }
 String publisherUrlFromGoogle(String h){
  // Google wrappers may contain publisher targets as normal, escaped or query-param URLs.
  String decoded=decodeUrl(h);
  for(String regex:new String[]{
   "<meta[^>]+property=[\"']og:url[\"'][^>]+content=[\"']([^\"']+)",
   "<a[^>]+href=[\"'](https?://[^\"']+)[\"']",
   "[?&](?:url|q|u)=((?:https?%3A%2F%2F)[^&\"']+)"
  }){
   Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE).matcher(decoded);
   while(m.find()){
    String u=m.group(1);
    try{u=URLDecoder.decode(u,"UTF-8");}catch(Throwable ignored){}
    u=decodeUrl(u);if(isPublisher(u)&&u.length()<1500)return u;
   }
  }
  Matcher m=Pattern.compile("https?://[^\\\"'<>\\\\ ]+").matcher(decoded);
  while(m.find()){String u=decodeUrl(m.group());if(isPublisher(u)&&u.length()<1500)return u;}
  return null;
 }
 boolean isPublisher(String u){
  if(u==null||!u.startsWith("http"))return false;
  String x=u.toLowerCase();
  return !(x.contains("google.com")||x.contains("gstatic.com")||x.contains("googleusercontent.com")||x.contains("schema.org")||x.contains("w3.org"));
 }
 String decodeUrl(String u){
  if(u==null)return null;
  u=Html.fromHtml(u,0).toString().replace("\\u003d","=").replace("\\u0026","&").replace("\\/","/");
  return u;
 }
 String imageFromHtml(String h,String base){
  ArrayList<String> candidates=new ArrayList<>();
  Matcher meta=Pattern.compile("<meta\\b[^>]*>",Pattern.CASE_INSENSITIVE).matcher(h);
  while(meta.find()){
   String tag=meta.group(),key=attr(tag,"property");if(key==null)key=attr(tag,"name");
   if(key!=null&&(key.equalsIgnoreCase("og:image")||key.equalsIgnoreCase("og:image:url")||key.equalsIgnoreCase("twitter:image")||key.equalsIgnoreCase("twitter:image:src"))){
    String u=attr(tag,"content");if(u!=null)candidates.add(u);
   }
  }
  Matcher link=Pattern.compile("<link\\b[^>]*>",Pattern.CASE_INSENSITIVE).matcher(h);
  while(link.find()){String tag=link.group(),rel=attr(tag,"rel");if(rel!=null&&rel.toLowerCase().contains("image_src")){String u=attr(tag,"href");if(u!=null)candidates.add(u);}}
  Matcher json=Pattern.compile("[\"'](?:image|imageUrl|thumbnailUrl|contentUrl)[\"']\\s*:\\s*(?:\\{[^}]*?[\"']url[\"']\\s*:\\s*)?[\"'](https?[^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h);
  while(json.find())candidates.add(json.group(1));
  Matcher imgs=Pattern.compile("<img\\b[^>]*>",Pattern.CASE_INSENSITIVE).matcher(h);int count=0;
  while(imgs.find()&&count++<30){String tag=imgs.group();for(String a:new String[]{"data-original","data-src","src"}){String u=attr(tag,a);if(u!=null)candidates.add(u);}String set=attr(tag,"srcset");if(set!=null){String[] ps=set.split(",");if(ps.length>0)candidates.add(ps[ps.length-1].trim().split("\\s+")[0]);}}
  LinkedHashSet<String> unique=new LinkedHashSet<>(candidates);
  for(String raw:unique){String u=absolute(decodeUrl(raw),base);if(goodImage(u))return u;}
  return null;
 }
 boolean imageReachable(String u){
  try{
   HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setInstanceFollowRedirects(true);
   c.setRequestMethod("GET");c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");
   c.setRequestProperty("Accept","image/avif,image/webp,image/apng,image/*,*/*;q=0.8");c.setConnectTimeout(4500);c.setReadTimeout(4500);
   int code=c.getResponseCode();String ct=c.getContentType();int len=c.getContentLength();
   c.disconnect();return code>=200&&code<400&&ct!=null&&ct.toLowerCase().startsWith("image/")&&(len!=0);
  }catch(Throwable e){return false;}
 }
 String attr(String tag,String name){
  Matcher m=Pattern.compile("\\b"+Pattern.quote(name)+"\\s*=\\s*[\"']([^\"']+)[\"']",Pattern.CASE_INSENSITIVE).matcher(tag);
  return m.find()?m.group(1):null;
 }
 String absolute(String u,String base){
  if(u==null||u.trim().isEmpty())return null;
  try{return new URL(new URL(base),u.trim()).toString();}catch(Throwable e){return u;}
 }
 String publisherName(String u){
  try{String h=new URL(u).getHost().toLowerCase().replaceFirst("^www\\.","");if(h.endsWith("klix.ba"))return "Klix.ba";if(h.endsWith("avaz.ba"))return "Avaz";if(h.endsWith("vijesti.ba"))return "Vijesti.ba";if(h.endsWith("nezavisne.com"))return "Nezavisne";return h;}catch(Throwable e){return null;}
 }
 ArrayList<Item> directSite(String page,String host,String source)throws Exception{
  ArrayList<Item> out=new ArrayList<>();String h=html(page);if(h==null)return out;
  LinkedHashSet<String> links=new LinkedHashSet<>();
  Matcher m=Pattern.compile("href=[\"']([^\"'#]+)[\"']",Pattern.CASE_INSENSITIVE).matcher(h);
  while(m.find()&&links.size()<45){
   String u=absolute(decodeUrl(m.group(1)),page);
   try{String uh=new URL(u).getHost().toLowerCase();if(uh.endsWith(host)&&!u.equals(page)&&!u.contains("/tag/")&&!u.contains("/pages/")&&!u.contains("/category/"))links.add(u);}catch(Throwable ignored){}
  }
  int count=0;
  for(String u:links){
   if(count>=18)break;String a=html(u);if(a==null)continue;
   String title=meta(a,"property","og:title");if(title==null)title=meta(a,"name","twitter:title");
   String img=imageFromHtml(a,u);
   if(title==null||title.trim().length()<12)continue;
   Item i=new Item(Html.fromHtml(title,0).toString(),u,source,System.currentTimeMillis()-count*60000L);
   i.url=u;i.image=img;out.add(i);count++;
  }
  return out;
 }
 String html(String u){
  try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");c.setConnectTimeout(6500);c.setReadTimeout(6500);InputStream in=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n,total=0;while((n=in.read(x))>0&&total<900000){b.write(x,0,n);total+=n;}in.close();return b.toString("UTF-8");}catch(Throwable e){return null;}
 }
 String meta(String h,String key,String val){
  Matcher m=Pattern.compile("<meta[^>]+"+key+"=[\"']"+Pattern.quote(val)+"[\"'][^>]+content=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h);
  if(m.find())return decodeUrl(m.group(1));
  m=Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+"+key+"=[\"']"+Pattern.quote(val)+"[\"']",Pattern.CASE_INSENSITIVE).matcher(h);
  return m.find()?decodeUrl(m.group(1)):null;
 }
 ArrayList<Item> fetch(String q)throws Exception{String z=q.toLowerCase();if(z.equals("site:klix.ba")||z.equals("klix.ba"))return directSite("https://www.klix.ba","klix.ba","Klix.ba");if(z.equals("site:avaz.ba")||z.equals("avaz.ba"))return directSite("https://avaz.ba","avaz.ba","Avaz");if(z.equals("site:vijesti.ba")||z.equals("vijesti.ba"))return directSite("https://www.vijesti.ba/sve-vijesti","vijesti.ba","Vijesti.ba");if(z.equals("site:nezavisne.com")||z.equals("nezavisne.com"))return directSite("https://www.nezavisne.com","nezavisne.com","Nezavisne");if(q.startsWith("http"))return parse(q);String query=q.contains(".")&&!q.contains(" ")&&!q.startsWith("site:")?"site:"+q:q;String u="https://news.google.com/rss/search?q="+URLEncoder.encode(query,"UTF-8")+"&hl=bs&gl=BA&ceid=BA:bs";return parse(u);}
 ArrayList<Item> parse(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestProperty("User-Agent","Mozilla/5.0");c.setConnectTimeout(7000);c.setReadTimeout(7000);DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();Document d=f.newDocumentBuilder().parse(c.getInputStream());NodeList ns=d.getElementsByTagName("item");ArrayList<Item> out=new ArrayList<>();
  for(int n=0;n<ns.getLength()&&n<30;n++){Element e=(Element)ns.item(n);String title=t(e,"title"),link=t(e,"link"),date=t(e,"pubDate"),src="";NodeList sn=e.getElementsByTagName("source");if(sn.getLength()>0)src=sn.item(0).getTextContent();if(src.isEmpty())src="Vijesti";Item i=new Item(title,link,src,date(date));i.image=feedImage(e);out.add(i);}return out;}
 String feedImage(Element e){
  for(String tag:new String[]{"media:content","media:thumbnail","enclosure","image"}){NodeList n=e.getElementsByTagName(tag);for(int j=0;j<n.getLength();j++){Element x=(Element)n.item(j);String u=x.getAttribute("url");if(u.isEmpty())u=x.getTextContent().trim();if(goodImage(u))return u;}}
  String h=t(e,"description")+" "+t(e,"content:encoded");
  Matcher m=Pattern.compile("<img[^>]+(?:src|data-src|data-original)=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h);
  while(m.find()){String u=Html.fromHtml(m.group(1),0).toString();if(goodImage(u))return u;}
  return null;
 }
 static boolean goodImage(String u){if(u==null||!u.startsWith("http"))return false;String x=u.toLowerCase();return !(x.contains("gstatic.com")||x.contains("google.com/images")||x.contains("google_news")||x.contains("googlenews")||x.contains("news.google.com"));}
 String t(Element e,String n){NodeList x=e.getElementsByTagName(n);return x.getLength()>0?x.item(0).getTextContent():"";}
 long date(String d){for(String p:new String[]{"EEE, dd MMM yyyy HH:mm:ss z","EEE, dd MMM yyyy HH:mm:ss Z"})try{return new SimpleDateFormat(p,Locale.US).parse(d).getTime();}catch(Exception e){}return 0;}
 String clean(String a,String s){String x=Html.fromHtml(a,0).toString().trim();if(s!=null&&!s.isEmpty())x=x.replaceAll("\\s+-\\s+"+Pattern.quote(s)+"\\s*$","").trim();return x;}
 static String rel(long t){if(t<=0)return"novo";long m=Math.max(1,(System.currentTimeMillis()-t)/60000);if(m<60)return m+"m";if(m<1440)return(m/60)+"h";return(m/1440)+"d";}
 int dp(int x){return(int)(x*getResources().getDisplayMetrics().density);}
 static class Item{String title,cleanTitle,link,source,url,image;long when;Item(String a,String b,String c,long d){title=a;cleanTitle=a;link=b;source=c;url=b;when=d;}}
}
