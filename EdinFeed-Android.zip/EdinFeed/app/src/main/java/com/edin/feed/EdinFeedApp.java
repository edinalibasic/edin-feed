package com.edin.feed;
import android.app.Application;
import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;
import okhttp3.*;
import java.io.IOException;
public class EdinFeedApp extends Application{
 public void onCreate(){super.onCreate();
  OkHttpClient client=new OkHttpClient.Builder().followRedirects(true).followSslRedirects(true).addInterceptor(new Interceptor(){
   public Response intercept(Chain chain)throws IOException{
    Request old=chain.request();String host=old.url().host();
    String ref=host.contains("klix")?"https://www.klix.ba/":host.contains("nezavisne")?"https://www.nezavisne.com/":host.contains("avaz")?"https://avaz.ba/":host.contains("vijesti")?"https://www.vijesti.ba/":"https://"+host+"/";
    return chain.proceed(old.newBuilder().header("User-Agent","Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36").header("Accept","image/avif,image/webp,image/apng,image/*,*/*;q=0.8").header("Referer",ref).build());
   }}).build();
  try{Picasso.setSingletonInstance(new Picasso.Builder(this).downloader(new OkHttp3Downloader(client)).build());}catch(IllegalStateException ignored){}
 }
}