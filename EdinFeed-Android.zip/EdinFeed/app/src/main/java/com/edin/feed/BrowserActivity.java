package com.edin.feed;
import android.app.*;import android.os.*;import android.content.*;import android.net.*;import android.view.*;import android.webkit.*;import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;import java.util.*;

public class BrowserActivity extends AppCompatActivity{
 WebView web;String url;
 static final String[] BLOCK={"doubleclick.net","googlesyndication.com","googleadservices.com","adservice.google.","amazon-adsystem.com","criteo.com","taboola.com","outbrain.com","adnxs.com","scorecardresearch.com","zedo.com","adsrvr.org"};
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_browser);url=getIntent().getStringExtra("url");
  ((TextView)findViewById(R.id.browserTitle)).setText(getIntent().getStringExtra("title"));
  findViewById(R.id.back).setOnClickListener(v->{if(web.canGoBack())web.goBack();else finish();});
  findViewById(R.id.external).setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(web.getUrl())));}catch(Throwable e){}});
  ProgressBar bar=findViewById(R.id.progress);web=findViewById(R.id.web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setLoadsImagesAutomatically(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
  web.setWebChromeClient(new WebChromeClient(){public void onProgressChanged(WebView v,int p){bar.setProgress(p);bar.setVisibility(p>=100?View.GONE:View.VISIBLE);}});
  web.setWebViewClient(new WebViewClient(){
   public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){Uri u=r.getUrl();if(u!=null&&("http".equals(u.getScheme())||"https".equals(u.getScheme())))return false;return true;}
   public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){String h=r.getUrl().getHost();if(h!=null){h=h.toLowerCase();for(String x:BLOCK)if(h.contains(x))return empty();}return super.shouldInterceptRequest(v,r);}
   public void onPageFinished(WebView v,String u){super.onPageFinished(v,u);clean(v);}
  });if(url!=null)web.loadUrl(url);
 }
 static WebResourceResponse empty(){return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));}
 void clean(WebView v){String js="javascript:(function(){var s=document.createElement('style');s.innerHTML='iframe[src*=ad], [id*=advert], [class*=advert], [id*=banner], [class*=banner], [class*=cookie], [id*=cookie], [class*=consent], [id*=consent], [class*=paywall-ad], [class*=sticky-ad]{display:none!important}';document.head.appendChild(s);})();";v.evaluateJavascript(js,null);}
 public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
