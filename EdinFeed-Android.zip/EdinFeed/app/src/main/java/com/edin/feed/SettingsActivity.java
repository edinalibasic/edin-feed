package com.edin.feed;
import android.content.*;import android.os.*;import androidx.appcompat.app.AppCompatActivity;
public class SettingsActivity extends AppCompatActivity{
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings);
  findViewById(R.id.back).setOnClickListener(v->finish());
  findViewById(R.id.sources).setOnClickListener(v->startActivity(new Intent(this,SourcesActivity.class)));
 }
}
