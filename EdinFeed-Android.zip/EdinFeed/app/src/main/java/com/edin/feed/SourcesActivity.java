package com.edin.feed;
import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import java.util.*;
public class SourcesActivity extends AppCompatActivity{
 LinearLayout items;EditText input;LinkedHashSet<String>s;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_sources);items=findViewById(R.id.items);input=findViewById(R.id.input);s=SourceStore.get(this);render();
 findViewById(R.id.back).setOnClickListener(v->finish());findViewById(R.id.add).setOnClickListener(v->{String x=input.getText().toString().trim();if(!x.isEmpty()){s.add(x);SourceStore.save(this,s);input.setText("");render();}});}
 void render(){items.removeAllViews();for(String x:new ArrayList<>(s)){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView t=new TextView(this);t.setText(x);t.setTextSize(16);t.setTextColor(Color.DKGRAY);t.setPadding(2,14,2,14);r.addView(t,new LinearLayout.LayoutParams(0,-2,1));Button b=new Button(this);b.setText("Ukloni");b.setOnClickListener(v->{s.remove(x);SourceStore.save(this,s);render();});r.addView(b);items.addView(r);}}
}
