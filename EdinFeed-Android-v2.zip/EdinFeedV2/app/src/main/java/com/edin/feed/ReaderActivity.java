package com.edin.feed;
import android.os.Bundle;
import android.webkit.*;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ReaderActivity extends AppCompatActivity {
 WebView web;
 @Override public void onCreate(Bundle b){
  super.onCreate(b); setContentView(R.layout.activity_reader);
  findViewById(R.id.back).setOnClickListener(v->finish());
  web=findViewById(R.id.web);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  web.setWebViewClient(new WebViewClient(){
   @Override public void onPageFinished(WebView v,String url){
    // Reader-like cleanup: remove common ads/nav/overlays while keeping article content.
    String js="javascript:(function(){"+
      "var sels=['iframe','aside','nav','header','footer','[class*=advert]','[id*=advert]','[class*=banner]','[class*=cookie]','[id*=cookie]','[class*=popup]','[class*=modal]'];"+
      "sels.forEach(s=>document.querySelectorAll(s).forEach(e=>e.remove()));"+
      "document.body.style.maxWidth='760px';document.body.style.margin='0 auto';document.body.style.fontSize='19px';document.body.style.lineHeight='1.65';"+
      "document.querySelectorAll('img').forEach(i=>{i.style.maxWidth='100%';i.style.height='auto'});"+
      "})();";
    v.evaluateJavascript(js,null);
   }
  });
  web.loadUrl(getIntent().getStringExtra("url"));
 }
 @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
