package com.edin.feed;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.squareup.picasso.Picasso;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends AppCompatActivity {
 LinearLayout feed; SwipeRefreshLayout swipe;
 final String[] searches={
  "Živinice","Tuzla OR \"Tuzlanski kanton\"",
  "site:klix.ba Bosna","site:avaz.ba Bosna","site:vijesti.ba Bosna","site:nezavisne.com Bosna",
  "Augsburg Germany","AI software development Java","technology Germany"
 };
 @Override public void onCreate(Bundle b){
  super.onCreate(b); setContentView(R.layout.activity_main);
  feed=findViewById(R.id.feed); swipe=findViewById(R.id.swipe);
  swipe.setOnRefreshListener(this::load); load();
 }
 void load(){
  swipe.setRefreshing(true); feed.removeAllViews();
  ExecutorService ex=Executors.newFixedThreadPool(6);
  ex.submit(()->{
   List<Item> all=new ArrayList<>();
   for(String q:searches) try{all.addAll(fetch(q));}catch(Exception ignored){}
   LinkedHashMap<String,Item> uniq=new LinkedHashMap<>();
   for(Item i:all){
    String k=i.title.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]","");
    if(!uniq.containsKey(k)) uniq.put(k,i);
   }
   List<Item> items=new ArrayList<>(uniq.values());
   items.sort((a,b)->Long.compare(b.when,a.when));
   // Resolve Google News links + article og:image in parallel.
   List<Future<?>> fs=new ArrayList<>();
   for(int n=0;n<Math.min(30,items.size());n++){
    Item it=items.get(n);
    fs.add(ex.submit(()->enrich(it)));
   }
   for(Future<?> f:fs) try{f.get(8,TimeUnit.SECONDS);}catch(Exception ignored){}
   runOnUiThread(()->{
    int n=0; for(Item i:items){addCard(i); if(++n>=30)break;}
    swipe.setRefreshing(false);
   });
  });
 }
 List<Item> fetch(String q)throws Exception{
  String u="https://news.google.com/rss/search?q="+URLEncoder.encode(q,"UTF-8")+"&hl=bs&gl=BA&ceid=BA:bs";
  HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
  c.setRequestProperty("User-Agent","Mozilla/5.0 EdinFeed"); c.setConnectTimeout(9000);c.setReadTimeout(9000);
  Document d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(c.getInputStream());
  NodeList ns=d.getElementsByTagName("item"); List<Item> out=new ArrayList<>();
  for(int x=0;x<ns.getLength();x++){
   Element e=(Element)ns.item(x); String title=t(e,"title"),link=t(e,"link"),date=t(e,"pubDate"),src="";
   NodeList ss=e.getElementsByTagName("source"); if(ss.getLength()>0)src=ss.item(0).getTextContent();
   long when=0;try{when=new Date(date).getTime();}catch(Exception ignored){}
   out.add(new Item(title,link,src,date,when));
  } return out;
 }
 String t(Element e,String n){NodeList x=e.getElementsByTagName(n);return x.getLength()>0?x.item(0).getTextContent():"";}
 void enrich(Item i){
  try{
   HttpURLConnection c=(HttpURLConnection)new URL(i.link).openConnection();
   c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","Mozilla/5.0");c.setConnectTimeout(7000);c.setReadTimeout(7000);
   c.connect(); i.url=c.getURL().toString();
   String ct=c.getContentType();
   if(ct!=null && ct.contains("text")){
    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
    StringBuilder sb=new StringBuilder();String line;int size=0;
    while((line=br.readLine())!=null && size<400000){sb.append(line);size+=line.length();}
    String html=sb.toString();
    Matcher m=Pattern.compile("<meta[^>]+(?:property|name)=[\"']og:image[\"'][^>]+content=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(html);
    if(!m.find()) m=Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"']og:image[\"']",Pattern.CASE_INSENSITIVE).matcher(html);
    if(m.find()) i.image=Html.fromHtml(m.group(1),Html.FROM_HTML_MODE_LEGACY).toString();
   }
  }catch(Exception ignored){}
  if(i.url==null)i.url=i.link;
 }
 void addCard(Item i){
  LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setBackgroundColor(Color.WHITE);
  LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,12);card.setLayoutParams(cp);
  if(i.image!=null && !i.image.isEmpty()){
   ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);
   im.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(235)));
   Picasso.get().load(i.image).fit().centerCrop().into(im);card.addView(im);
  }
  TextView title=new TextView(this);title.setText(Html.fromHtml(i.title,Html.FROM_HTML_MODE_LEGACY));
  title.setTextSize(22);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setTextColor(Color.rgb(32,33,36));
  title.setPadding(dp(16),dp(15),dp(16),dp(8));card.addView(title);
  LinearLayout meta=new LinearLayout(this);meta.setGravity(Gravity.CENTER_VERTICAL);meta.setPadding(dp(16),0,dp(10),dp(16));
  TextView source=new TextView(this);source.setText((i.source.isEmpty()?"Vijesti":i.source)+" · "+relative(i.when));
  source.setTextSize(14);source.setTextColor(Color.rgb(80,80,80));meta.addView(source,new LinearLayout.LayoutParams(0,-2,1));
  TextView heart=icon("♡");TextView share=icon("⌯");TextView more=icon("⋮");
  meta.addView(heart);meta.addView(share);meta.addView(more);card.addView(meta);
  card.setOnClickListener(v->{Intent in=new Intent(this,ReaderActivity.class);in.putExtra("url",i.url);startActivity(in);});
  share.setOnClickListener(v->{Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,i.title+"\n"+i.url);startActivity(Intent.createChooser(s,"Podijeli"));});
  heart.setOnClickListener(v->heart.setText(heart.getText().toString().equals("♡")?"♥":"♡"));
  feed.addView(card);
 }
 TextView icon(String s){TextView v=new TextView(this);v.setText(s);v.setTextSize(27);v.setGravity(Gravity.CENTER);v.setPadding(dp(11),0,dp(11),0);return v;}
 int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
 String relative(long t){if(t<=0)return "novo";long m=(System.currentTimeMillis()-t)/60000;if(m<60)return Math.max(1,m)+"m";if(m<1440)return (m/60)+"h";return (m/1440)+"d";}
 static class Item{String title,link,source,date,url,image;long when;Item(String a,String b,String c,String d,long e){title=a;link=b;source=c;date=d;when=e;}}
}
