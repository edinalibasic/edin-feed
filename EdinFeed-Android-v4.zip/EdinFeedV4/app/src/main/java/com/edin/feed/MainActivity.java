package com.edin.feed;
import android.content.*;import android.graphics.Color;import android.os.*;import android.text.Html;import android.view.*;import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;import androidx.recyclerview.widget.*;import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import org.w3c.dom.*;import javax.xml.parsers.*;import java.net.*;import java.io.*;import java.text.*;import java.util.*;import java.util.concurrent.*;import java.util.regex.*;
public class MainActivity extends AppCompatActivity implements NewsAdapter.Actions{
 RecyclerView rv;SwipeRefreshLayout swipe;LinearLayout cats;NewsAdapter adapter;final List<Item> all=new ArrayList<>(),shown=new ArrayList<>();ExecutorService pool=Executors.newFixedThreadPool(8);
 int page=0;final int PAGE=12;boolean loading=false;String category="Sve";long lastSourceStamp=0;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);rv=findViewById(R.id.list);swipe=findViewById(R.id.swipe);cats=findViewById(R.id.categories);
  rv.setLayoutManager(new LinearLayoutManager(this));adapter=new NewsAdapter(this,shown,this);rv.setAdapter(adapter);makeCats();
  findViewById(R.id.sources).setOnClickListener(v->startActivity(new Intent(this,SourcesActivity.class)));swipe.setOnRefreshListener(this::reload);
  rv.addOnScrollListener(new RecyclerView.OnScrollListener(){public void onScrolled(RecyclerView r,int dx,int dy){LinearLayoutManager lm=(LinearLayoutManager)r.getLayoutManager();if(!loading&&lm.findLastVisibleItemPosition()>=shown.size()-4)appendPage();}});
  reload();
 }
 void makeCats(){String[] a={"Sve","BiH","Njemačka","Tehnologija","Berza"};for(String x:a){TextView v=new TextView(this);v.setText(x);v.setTextSize(16);v.setPadding(dp(17),dp(9),dp(17),dp(9));v.setOnClickListener(z->{category=x;styleCats();applyCategory();});v.setTag(x);cats.addView(v);}styleCats();}
 void styleCats(){for(int i=0;i<cats.getChildCount();i++){TextView v=(TextView)cats.getChildAt(i);boolean on=v.getTag().equals(category);v.setTextColor(on?Color.WHITE:Color.DKGRAY);v.setBackgroundResource(on?R.drawable.chip:0);}}
 void reload(){if(loading)return;loading=true;swipe.setRefreshing(true);pool.submit(()->{List<Item> tmp=new ArrayList<>();for(String s:SourceStore.get(this))try{tmp.addAll(fetch(s));}catch(Exception e){}
   LinkedHashMap<String,Item> u=new LinkedHashMap<>();for(Item i:tmp){String k=i.title.toLowerCase().replaceAll("[^\\p{L}\\p{N}]","");if(!u.containsKey(k))u.put(k,i);}
   tmp=new ArrayList<>(u.values());tmp.sort((a,b)->Long.compare(b.when,a.when));
   List<Future<?>> fs=new ArrayList<>();for(int n=0;n<Math.min(60,tmp.size());n++){Item i=tmp.get(n);fs.add(pool.submit(()->enrich(i)));}
   for(Future<?> f:fs)try{f.get(8,TimeUnit.SECONDS);}catch(Exception e){}
   List<Item> fin=tmp;runOnUiThread(()->{all.clear();all.addAll(fin);loading=false;swipe.setRefreshing(false);applyCategory();});
  });}
 void applyCategory(){shown.clear();page=0;appendPage();}
 List<Item> filtered(){if(category.equals("Sve"))return new ArrayList<>(all);List<Item> r=new ArrayList<>();for(Item i:all){String s=(i.title+" "+i.source).toLowerCase();
  boolean ok=category.equals("BiH")&&(s.contains("bih")||s.contains("bosn")||s.contains("tuz")||s.contains("živin")||s.contains("klix")||s.contains("avaz")||s.contains("vijesti")||s.contains("nezavis"));
  if(category.equals("Njemačka"))ok=s.contains("german")||s.contains("njema")||s.contains("augsburg")||s.contains("berlin")||s.contains("münchen");
  if(category.equals("Tehnologija"))ok=s.contains("tech")||s.contains(" ai ")||s.contains("software")||s.contains("android")||s.contains("google")||s.contains("apple");
  if(category.equals("Berza"))ok=s.contains("stock")||s.contains("market")||s.contains("berza")||s.contains("nasdaq")||s.contains("invest");
  if(ok)r.add(i);}return r;}
 void appendPage(){List<Item> f=filtered();int start=shown.size();if(start>=f.size())return;int end=Math.min(start+PAGE,f.size());shown.addAll(f.subList(start,end));adapter.notifyItemRangeInserted(start,end-start);page++;}
 List<Item> fetch(String q)throws Exception{
  if(q.startsWith("http")){try{return parseRss(q);}catch(Exception e){String host=new URL(q).getHost();return google("site:"+host);}}
  String query=q.contains(".")&&!q.contains(" ")&&!q.startsWith("site:")?"site:"+q:q;return google(query);
 }
 List<Item> google(String q)throws Exception{return parseRss("https://news.google.com/rss/search?q="+URLEncoder.encode(q,"UTF-8")+"&hl=bs&gl=BA&ceid=BA:bs");}
 List<Item> parseRss(String url)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestProperty("User-Agent","Mozilla/5.0");c.setConnectTimeout(9000);c.setReadTimeout(9000);
  DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(false);Document d=f.newDocumentBuilder().parse(c.getInputStream());NodeList ns=d.getElementsByTagName("item");List<Item> out=new ArrayList<>();
  for(int x=0;x<ns.getLength();x++){Element e=(Element)ns.item(x);String title=t(e,"title"),link=t(e,"link"),date=t(e,"pubDate"),src="";
   NodeList ss=e.getElementsByTagName("source");if(ss.getLength()>0)src=ss.item(0).getTextContent();if(src.isEmpty())try{src=new URL(link).getHost().replace("www.","");}catch(Exception z){}
   long when=parseDate(date);Item i=new Item(title,link,src,when);i.image=findFeedImage(e);out.add(i);}return out;
 }
 String findFeedImage(Element e){String[] tags={"media:content","media:thumbnail","enclosure"};for(String tag:tags){NodeList n=e.getElementsByTagName(tag);for(int k=0;k<n.getLength();k++){Element z=(Element)n.item(k);String u=z.getAttribute("url");String type=z.getAttribute("type");if(!u.isEmpty()&&(tag.startsWith("media")||type.startsWith("image")))return u;}}
  String h=t(e,"description")+" "+t(e,"content:encoded");Matcher m=Pattern.compile("<img[^>]+(?:src|data-src)=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h);return m.find()?m.group(1):null;}
 String t(Element e,String n){NodeList x=e.getElementsByTagName(n);return x.getLength()>0?x.item(0).getTextContent():"";}
 long parseDate(String d){String[] p={"EEE, dd MMM yyyy HH:mm:ss z","EEE, dd MMM yyyy HH:mm:ss Z","yyyy-MM-dd'T'HH:mm:ssXXX"};for(String q:p)try{return new SimpleDateFormat(q,Locale.US).parse(d).getTime();}catch(Exception e){}return 0;}
 void enrich(Item i){
  i.url=i.link;
  // Direct article feeds are enriched from the original page. Google News links are left intact if redirect cannot be resolved.
  try{HttpURLConnection c=(HttpURLConnection)new URL(i.link).openConnection();c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");c.setConnectTimeout(7000);c.setReadTimeout(7000);c.connect();String resolved=c.getURL().toString();if(!resolved.isEmpty())i.url=resolved;
   if(i.image==null&&c.getContentType()!=null&&c.getContentType().contains("text")){BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String l;int n=0;while((l=br.readLine())!=null&&n<600000){b.append(l);n+=l.length();}
    String h=b.toString();Matcher m=Pattern.compile("<meta[^>]+(?:property|name)=[\"'](?:og:image|twitter:image)[\"'][^>]+content=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h);if(!m.find())m=Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"'](?:og:image|twitter:image)[\"']",Pattern.CASE_INSENSITIVE).matcher(h);if(m.find())i.image=Html.fromHtml(m.group(1),0).toString();}
  }catch(Exception e){}
  i.cleanTitle=clean(i.title,i.source);
 }
 String clean(String t,String s){String x=Html.fromHtml(t,0).toString().trim();if(s!=null&&!s.isEmpty()){x=x.replaceAll("\\s+-\\s+"+Pattern.quote(s)+"\\s*$","").trim();}return x;}
 public void hideSource(Item i){shown.remove(i);adapter.notifyDataSetChanged();}
 static String rel(long t){if(t<=0)return"novo";long m=Math.max(1,(System.currentTimeMillis()-t)/60000);if(m<60)return m+"m";if(m<1440)return(m/60)+"h";return(m/1440)+"d";}
 int dp(int x){return(int)(x*getResources().getDisplayMetrics().density);}
 static class Item{String title,cleanTitle,link,source,url,image;long when;Item(String a,String b,String c,long d){title=a;cleanTitle=a;link=b;source=c;when=d;}}
}
