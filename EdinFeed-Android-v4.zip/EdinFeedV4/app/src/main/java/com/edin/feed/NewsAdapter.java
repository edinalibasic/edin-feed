package com.edin.feed;
import android.content.*;import android.graphics.drawable.ColorDrawable;import android.view.*;import android.widget.*;import androidx.recyclerview.widget.RecyclerView;import androidx.browser.customtabs.CustomTabsIntent;import com.squareup.picasso.*;
import java.util.*;
public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.H>{
 interface Actions{void hideSource(MainActivity.Item i);}
 Context c;List<MainActivity.Item> data;Actions actions;
 NewsAdapter(Context c,List<MainActivity.Item>d,Actions a){this.c=c;data=d;actions=a;}
 public H onCreateViewHolder(ViewGroup p,int t){return new H(LayoutInflater.from(c).inflate(R.layout.item_news,p,false));}
 public void onBindViewHolder(H h,int pos){MainActivity.Item i=data.get(pos);h.title.setText(i.cleanTitle);h.source.setText(i.source+" · "+MainActivity.rel(i.when));
  h.image.setVisibility(View.GONE);h.image.setImageDrawable(null);
  if(i.image!=null&&!i.image.isEmpty()){h.image.setVisibility(View.VISIBLE);Picasso.get().load(i.image).placeholder(new ColorDrawable(0xffeeeeee)).error(new ColorDrawable(0xffeeeeee)).fit().centerCrop().into(h.image);}
  h.card.setOnClickListener(v->open(i.url));h.title.setOnClickListener(v->open(i.url));h.image.setOnClickListener(v->open(i.url));
  h.heart.setOnClickListener(v->h.heart.setText(h.heart.getText().toString().equals("♡")?"♥":"♡"));
  h.share.setOnClickListener(v->{Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,i.cleanTitle+"\n"+i.url);c.startActivity(Intent.createChooser(s,"Podijeli"));});
  h.more.setOnClickListener(v->{PopupMenu p=new PopupMenu(c,h.more);p.getMenu().add("Ne zanima me");p.getMenu().add("Manje ovakvih");p.getMenu().add("Sakrij izvor");p.setOnMenuItemClickListener(m->{if(m.getTitle().toString().startsWith("Sakrij"))actions.hideSource(i);return true;});p.show();});
 }
 void open(String url){try{new CustomTabsIntent.Builder().setShowTitle(true).build().launchUrl(c,android.net.Uri.parse(url));}catch(Exception e){Intent x=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url));c.startActivity(x);}}
 public int getItemCount(){return data.size();}
 static class H extends RecyclerView.ViewHolder{View card;ImageView image;TextView title,source,heart,share,more;H(View v){super(v);card=v.findViewById(R.id.card);image=v.findViewById(R.id.image);title=v.findViewById(R.id.title);source=v.findViewById(R.id.source);heart=v.findViewById(R.id.heart);share=v.findViewById(R.id.share);more=v.findViewById(R.id.more);}}
}
