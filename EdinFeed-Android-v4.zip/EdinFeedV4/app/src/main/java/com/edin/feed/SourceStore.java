package com.edin.feed;
import android.content.*;import java.util.*;
public class SourceStore{
 static final String P="sources4",K="items";
 // Direct RSS where known gives better original links/images; search terms stay supported.
 static final String[] D={"https://www.klix.ba/rss","Živinice","Tuzla OR \"Tuzlanski kanton\"","site:avaz.ba","site:vijesti.ba","https://www.nezavisne.com/rss/novosti.xml","Augsburg Germany","AI technology","stock market"};
 static LinkedHashSet<String> get(Context c){Set<String>s=c.getSharedPreferences(P,0).getStringSet(K,null);return s==null?new LinkedHashSet<>(Arrays.asList(D)):new LinkedHashSet<>(s);}
 static void save(Context c,Set<String>s){c.getSharedPreferences(P,0).edit().putStringSet(K,new HashSet<>(s)).apply();}
}
