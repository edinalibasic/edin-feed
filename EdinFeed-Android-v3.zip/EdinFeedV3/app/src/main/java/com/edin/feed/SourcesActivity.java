package com.edin.feed;
import android.os.*; import android.graphics.Color; import android.view.*; import android.widget.*; import androidx.appcompat.app.AppCompatActivity; import java.util.*;
public class SourcesActivity extends AppCompatActivity{
 LinearLayout list; EditText input; LinkedHashSet<String> sources;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_sources);list=findViewById(R.id.list);input=findViewById(R.id.input);sources=SourceStore.get(this);render();
  findViewById(R.id.back).setOnClickListener(v->finish());
  findViewById(R.id.add).setOnClickListener(v->{String x=input.getText().toString().trim();if(!x.isEmpty()){sources.add(x);SourceStore.save(this,sources);input.setText("");render();}});
 }
 void render(){list.removeAllViews();for(String s:sources){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(4,12,4,12);
  TextView t=new TextView(this);t.setText(s);t.setTextSize(17);t.setTextColor(Color.rgb(32,33,36));r.addView(t,new LinearLayout.LayoutParams(0,-2,1));
  Button del=new Button(this);del.setText("Ukloni");del.setOnClickListener(v->{sources.remove(s);SourceStore.save(this,sources);render();});r.addView(del);list.addView(r);}
 }
}
