package com.edin.feed;
import android.content.*;import android.net.Uri;import android.os.*;import android.webkit.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;
public class BrowserActivity extends AppCompatActivity{
 WebView web;String url;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_browser);url=getIntent().getStringExtra("url");web=findViewById(R.id.web);
  try{((TextView)findViewById(R.id.host)).setText(Uri.parse(url).getHost());}catch(Exception e){}
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setLoadsImagesAutomatically(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
  web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){v.loadUrl(r.getUrl().toString());return true;}});
  findViewById(R.id.back).setOnClickListener(v->{if(web.canGoBack())web.goBack();else finish();});
  findViewById(R.id.refresh).setOnClickListener(v->web.reload());
  findViewById(R.id.share).setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,web.getUrl());startActivity(Intent.createChooser(i,"Podijeli"));});
  web.loadUrl(url);
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
