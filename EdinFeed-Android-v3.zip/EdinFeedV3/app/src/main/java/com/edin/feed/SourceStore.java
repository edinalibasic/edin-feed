package com.edin.feed;
import android.content.*; import java.util.*;
public class SourceStore {
 static final String PREF="sources", KEY="items";
 static final String[] DEFAULTS={"site:klix.ba","site:avaz.ba","site:vijesti.ba","site:nezavisne.com","Živinice","Tuzla OR \"Tuzlanski kanton\"","Augsburg Germany","AI technology","stock market"};
 static LinkedHashSet<String> get(Context c){
  Set<String>s=c.getSharedPreferences(PREF,0).getStringSet(KEY,null);
  return s==null?new LinkedHashSet<>(Arrays.asList(DEFAULTS)):new LinkedHashSet<>(s);
 }
 static void save(Context c,Set<String>s){c.getSharedPreferences(PREF,0).edit().putStringSet(KEY,new HashSet<>(s)).apply();}
}
