package com.edin.feed;
import android.content.*;import android.graphics.*;import android.os.*;import android.text.Html;import android.view.*;import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;import com.squareup.picasso.Picasso;
import org.w3c.dom.*;import javax.xml.parsers.*;import java.net.*;import java.io.*;import java.text.*;import java.util.*;import java.util.concurrent.*;import java.util.regex.*;
public class MainActivity extends AppCompatActivity{
 LinearLayout feed;SwipeRefreshLayout swipe;ExecutorService pool=Executors.newFixedThreadPool(8);
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);feed=findViewById(R.id.feed);swipe=findViewById(R.id.swipe);
  findViewById(R.id.sources).setOnClickListener(v->startActivity(new Intent(this,SourcesActivity.class)));swipe.setOnRefreshListener(this::load);load();}
 @Override protected void onResume(){super.onResume();if(feed!=null&&feed.getChildCount()>0){}}
 void load(){swipe.setRefreshing(true);feed.removeAllViews();pool.submit(()->{
  List<Item> all=new ArrayList<>();for(String s:SourceStore.get(this)){try{all.addAll(fetch(s));}catch(Exception e){}}
  LinkedHashMap<String,Item> u=new LinkedHashMap<>();for(Item i:all){String k=i.title.toLowerCase().replaceAll("[^\\p{L}\\p{N}]","");if(!u.containsKey(k))u.put(k,i);}
  List<Item> items=new ArrayList<>(u.values());items.sort((a,b)->Long.compare(b.when,a.when));List<Future<?>> fs=new ArrayList<>();
  for(int n=0;n<Math.min(35,items.size());n++){Item i=items.get(n);fs.add(pool.submit(()->enrich(i)));}
  for(Future<?> f:fs)try{f.get(10,TimeUnit.SECONDS);}catch(Exception e){}
  runOnUiThread(()->{int n=0;for(Item i:items){addCard(i);if(++n>=35)break;}swipe.setRefreshing(false);});
 });}
 List<Item> fetch(String q)throws Exception{
  if(q.startsWith("http")&&(q.contains("rss")||q.endsWith(".xml")||q.contains("feed"))){return parseRss(q);}
  String query=q.contains(".")&&!q.contains(" ")&&!q.startsWith("site:")?"site:"+q:q;
  return parseRss("https://news.google.com/rss/search?q="+URLEncoder.encode(query,"UTF-8")+"&hl=bs&gl=BA&ceid=BA:bs");
 }
 List<Item> parseRss(String url)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestProperty("User-Agent","Mozilla/5.0");c.setConnectTimeout(9000);c.setReadTimeout(9000);
  Document d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(c.getInputStream());NodeList ns=d.getElementsByTagName("item");List<Item> out=new ArrayList<>();
  for(int x=0;x<ns.getLength();x++){Element e=(Element)ns.item(x);String title=t(e,"title"),link=t(e,"link"),date=t(e,"pubDate"),src="";
   NodeList ss=e.getElementsByTagName("source");if(ss.getLength()>0)src=ss.item(0).getTextContent();if(src.isEmpty())try{src=new URL(link).getHost().replace("www.","");}catch(Exception z){}
   long when=0;try{when=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.US).parse(date).getTime();}catch(Exception z){}
   Item i=new Item(title,link,src,when);String desc=t(e,"description");i.image=imageFromHtml(desc);out.add(i);}return out;
 }
 String t(Element e,String n){NodeList x=e.getElementsByTagName(n);return x.getLength()>0?x.item(0).getTextContent():"";}
 String imageFromHtml(String h){Matcher m=Pattern.compile("<img[^>]+src=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h==null?"":h);return m.find()?m.group(1):null;}
 void enrich(Item i){
  try{HttpURLConnection c=(HttpURLConnection)new URL(i.link).openConnection();c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");c.setConnectTimeout(8000);c.setReadTimeout(8000);c.connect();
   i.url=c.getURL().toString();if(i.image==null){BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String l;int z=0;while((l=br.readLine())!=null&&z<500000){b.append(l);z+=l.length();}
    String h=b.toString();Matcher m=Pattern.compile("<meta[^>]+(?:property|name)=[\"'](?:og:image|twitter:image)[\"'][^>]+content=[\"']([^\"']+)",Pattern.CASE_INSENSITIVE).matcher(h);
    if(!m.find())m=Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"'](?:og:image|twitter:image)[\"']",Pattern.CASE_INSENSITIVE).matcher(h);if(m.find())i.image=Html.fromHtml(m.group(1),0).toString();}
  }catch(Exception e){}if(i.url==null)i.url=i.link;
 }
 void addCard(Item i){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,10);card.setLayoutParams(cp);
  if(i.image!=null){ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(230)));Picasso.get().load(i.image).fit().centerCrop().into(im);card.addView(im);}
  TextView title=new TextView(this);title.setText(Html.fromHtml(i.title,0));title.setTextSize(22);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setTextColor(Color.rgb(32,33,36));title.setPadding(dp(18),dp(15),dp(18),dp(8));card.addView(title);
  LinearLayout meta=new LinearLayout(this);meta.setGravity(Gravity.CENTER_VERTICAL);meta.setPadding(dp(18),0,dp(8),dp(15));TextView src=new TextView(this);src.setText((i.source.isEmpty()?"Vijesti":i.source)+" · "+rel(i.when));src.setTextSize(14);src.setTextColor(Color.DKGRAY);meta.addView(src,new LinearLayout.LayoutParams(0,-2,1));
  TextView heart=ic("♡"),share=ic("⌯"),more=ic("⋮");meta.addView(heart);meta.addView(share);meta.addView(more);card.addView(meta);
  card.setOnClickListener(v->{Intent x=new Intent(this,BrowserActivity.class);x.putExtra("url",i.url);startActivity(x);});heart.setOnClickListener(v->heart.setText(heart.getText().equals("♡")?"♥":"♡"));
  share.setOnClickListener(v->{Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,i.title+"\n"+i.url);startActivity(Intent.createChooser(s,"Podijeli"));});
  more.setOnClickListener(v->{PopupMenu p=new PopupMenu(this,more);p.getMenu().add("Ne zanima me");p.getMenu().add("Manje ovakvih");p.getMenu().add("Sakrij izvor");p.show();});feed.addView(card);
 }
 TextView ic(String s){TextView v=new TextView(this);v.setText(s);v.setTextSize(27);v.setGravity(Gravity.CENTER);v.setPadding(dp(10),0,dp(10),0);return v;}int dp(int x){return(int)(x*getResources().getDisplayMetrics().density);}
 String rel(long t){if(t<=0)return"novo";long m=Math.max(1,(System.currentTimeMillis()-t)/60000);if(m<60)return m+"m";if(m<1440)return(m/60)+"h";return(m/1440)+"d";}
 static class Item{String title,link,source,url,image;long when;Item(String a,String b,String c,long d){title=a;link=b;source=c;when=d;}}
}
