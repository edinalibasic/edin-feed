# Edin Feed

Lokalna Android aplikacija za personalizovani news feed. Ne treba vlastiti server.
Telefon direktno dohvaća RSS rezultate preko interneta.

## Najlakši build samo s telefona

1. Na GitHubu napravi novi privatni repository, npr. `edin-feed`.
2. Raspakuj ovaj ZIP i uploaduj **sadržaj foldera EdinFeed** u repository.
3. Otvori karticu **Actions**.
4. Otvori **Build Edin Feed APK** i pokreni `Run workflow` (ili će se build pokrenuti nakon push-a).
5. Kada build završi, otvori ga i pod **Artifacts** preuzmi `EdinFeed-apk`.
6. Raspakuj artifact ZIP na telefonu i otvori `app-debug.apk`.
7. Android će možda tražiti dozvolu za instalaciju aplikacija iz browsera/Files aplikacije. Dozvoli samo za taj korak.

Napomena: Ovo je v1. Vijesti se otkrivaju preko Google News RSS-a, a klik otvara originalni članak.
Sljedeća verzija može dodati slike, lokalno "ne zanima me", bookmarke i direktnije RSS izvore.
