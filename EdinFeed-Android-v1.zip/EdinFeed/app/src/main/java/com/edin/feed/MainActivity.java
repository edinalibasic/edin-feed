package com.edin.feed;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {
    LinearLayout feed;
    SwipeRefreshLayout swipe;

    // Google News RSS is used as a discovery layer so the app can remain local
    // and avoid depending on fragile HTML scraping of each publisher.
    final String[] searches = new String[] {
        "Živinice",
        "Tuzla OR \"Tuzlanski kanton\"",
        "site:klix.ba Bosna",
        "site:avaz.ba Bosna",
        "site:vijesti.ba Bosna",
        "site:nezavisne.com Bosna",
        "Augsburg",
        "Germany technology AI Java software",
        "AI software development"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        feed = findViewById(R.id.feed);
        swipe = findViewById(R.id.swipe);
        swipe.setOnRefreshListener(this::load);
        load();
    }

    void load() {
        swipe.setRefreshing(true);
        feed.removeAllViews();
        addHeader("Edin Feed", "Živinice · Tuzla · BiH · Augsburg · Tech");
        ExecutorService ex = Executors.newFixedThreadPool(4);
        ex.submit(() -> {
            List<Item> all = new ArrayList<>();
            for (String q : searches) {
                try { all.addAll(fetch(q)); } catch (Exception ignored) {}
            }
            // de-duplicate by normalized title
            LinkedHashMap<String,Item> uniq = new LinkedHashMap<>();
            for (Item i : all) {
                String k=i.title.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]","");
                if (!uniq.containsKey(k)) uniq.put(k,i);
            }
            List<Item> items = new ArrayList<>(uniq.values());
            items.sort((a,b2)->Long.compare(b2.when,a.when));
            runOnUiThread(() -> {
                int n=0;
                for(Item i:items) {
                    addCard(i);
                    if(++n>=35) break;
                }
                if(n==0) addHeader("Nema učitanih vijesti", "Provjeri internet i povuci prema dolje.");
                swipe.setRefreshing(false);
            });
        });
        ex.shutdown();
    }

    List<Item> fetch(String query) throws Exception {
        String url="https://news.google.com/rss/search?q="+
                URLEncoder.encode(query,"UTF-8")+
                "&hl=bs&gl=BA&ceid=BA:bs";
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent","EdinFeed/1.0");
        InputStream in=c.getInputStream();
        Document d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(in);
        NodeList nodes=d.getElementsByTagName("item");
        List<Item> out=new ArrayList<>();
        for(int x=0;x<nodes.getLength();x++){
            Element e=(Element)nodes.item(x);
            String title=text(e,"title");
            String link=text(e,"link");
            String pub=text(e,"pubDate");
            String source="";
            NodeList ss=e.getElementsByTagName("source");
            if(ss.getLength()>0) source=ss.item(0).getTextContent();
            long when=0;
            try { when=new Date(pub).getTime(); } catch(Exception ignored){}
            out.add(new Item(title,link,source,pub,when));
        }
        return out;
    }

    String text(Element e,String tag){
        NodeList n=e.getElementsByTagName(tag);
        return n.getLength()>0?n.item(0).getTextContent():"";
    }

    void addHeader(String title,String sub){
        TextView t=new TextView(this);
        t.setText(title+"\n"+sub);
        t.setTextSize(26); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setTextColor(Color.rgb(32,33,36));
        t.setPadding(4,18,4,22);
        feed.addView(t);
    }

    void addCard(Item i){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(22,22,22,22);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);
        bp.setMargins(0,0,0,18);
        box.setLayoutParams(bp);
        box.setBackgroundResource(R.drawable.card_bg);

        TextView source=new TextView(this);
        source.setText((i.source.isEmpty()?"Vijesti":i.source)+"  ·  "+shortDate(i.date));
        source.setTextSize(13);
        source.setTextColor(Color.rgb(95,99,104));

        TextView title=new TextView(this);
        title.setText(Html.fromHtml(i.title,Html.FROM_HTML_MODE_LEGACY));
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setTextColor(Color.rgb(32,33,36));
        title.setPadding(0,10,0,4);

        box.addView(source); box.addView(title);
        box.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(i.link))));
        feed.addView(box);
    }

    String shortDate(String d){
        if(d==null || d.isEmpty()) return "novo";
        return d.replace(" +0000","").replace(" GMT","");
    }

    static class Item {
        String title,link,source,date; long when;
        Item(String a,String b,String c,String d,long e){title=a;link=b;source=c;date=d;when=e;}
    }
}
